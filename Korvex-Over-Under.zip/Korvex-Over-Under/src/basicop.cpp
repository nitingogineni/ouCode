#include "main.h"
#include <fstream>

using namespace std;

void wait(int sec) {
  pros::delay(sec);
}

void deployintake() {
}

void outtake() {
}


void intaketriball() {
}

void stopintake() {
}

void expandWings() {
}

void retractWings() {
}

void shootCata() {
}

void stopCata() {
}
