#include "main.h"
extern void deployintake();
extern void outtake();
extern void intaketriball();